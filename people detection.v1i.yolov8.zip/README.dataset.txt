# people detection > 2025-04-20 3:14pm
https://universe.roboflow.com/ashutosh-kiqr8/people-detection-i6bdg

Provided by a Roboflow user
License: CC BY 4.0

